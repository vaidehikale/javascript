
var x,y,chr;
for(x=6; x > 0; x--)
{
   for (y=1; y < x; y++)
     {
    chr=chr+("*");        
      }
 console.log(chr);
 chr='';    
}
