newEmail = function (email) {
    var split = email.split("@");
    var part1 = split[0];
    var avg = part1.length / 2;
    part1 = part1.substring(0, (part1.length - avg));
    part2 = split[1];
    return part1 + "...@" + part2;
 };
 document.write(newEmail("eddygrant@gmail.com"));