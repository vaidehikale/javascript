function truncate(string,words) {
    return string.split(" ").splice(0,words).join(" ");
}
console.log(truncate('The quick brown fox jumps over the lazy dog', 4));
